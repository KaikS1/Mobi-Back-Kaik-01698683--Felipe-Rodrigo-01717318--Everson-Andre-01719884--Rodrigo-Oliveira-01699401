
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface QuestoesScreenProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const QuestoesScreen = ({ onNavigate, onLogout }: QuestoesScreenProps) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);

  const questions = [
    {
      id: 1,
      question: "Qual é o órgão responsável pela segurança pública no Brasil?",
      options: [
        "Ministério da Justiça",
        "Ministério da Defesa", 
        "Secretaria de Segurança Pública",
        "Polícia Federal"
      ],
      correct: 0
    },
    {
      id: 2,
      question: "Qual a idade mínima para ingressar na Polícia Militar?",
      options: [
        "16 anos",
        "18 anos",
        "21 anos", 
        "25 anos"
      ],
      correct: 1
    },
    {
      id: 3,
      question: "O que significa a sigla PM?",
      options: [
        "Polícia Municipal",
        "Polícia Militar",
        "Polícia Metropolitana",
        "Polícia Marítima"
      ],
      correct: 1
    }
  ];

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer === questions[currentQuestion].correct) {
      setScore(score + 1);
    }
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      // Quiz completed
      alert(`Quiz finalizado! Você acertou ${score + (selectedAnswer === questions[currentQuestion].correct ? 1 : 0)} de ${questions.length} questões.`);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setScore(0);
  };

  return (
    <div className="min-h-screen bg-gray-200 p-4">
      <Card className="w-full max-w-sm mx-auto bg-white shadow-xl rounded-3xl overflow-hidden">
        <CardContent className="p-0">
          {/* Header */}
          <div className="bg-gray-300 p-8 text-center">
            <img 
              src="/lovable-uploads/693b503d-750d-4af9-ada6-fe7582742071.png" 
              alt="Tactical Team" 
              className="w-32 h-24 mx-auto mb-4 object-cover rounded-lg"
            />
            <h1 className="text-xl font-black text-black tracking-wider">
              DE OLHO NA VAGA
            </h1>
          </div>

          {/* Quiz Content */}
          <div className="p-6">
            <div className="bg-gray-600 text-white px-4 py-2 rounded font-bold text-center mb-4">
              Questões - {currentQuestion + 1}/{questions.length}
            </div>

            <div className="space-y-4">
              <div className="bg-gray-100 p-4 rounded-lg">
                <p className="font-semibold text-black mb-4">
                  {questions[currentQuestion].question}
                </p>
                
                <div className="space-y-2">
                  {questions[currentQuestion].options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleAnswerSelect(index)}
                      className={`w-full text-left p-3 rounded transition-colors ${
                        selectedAnswer === index 
                          ? 'bg-gray-600 text-white' 
                          : 'bg-white hover:bg-gray-200 text-black border border-gray-300'
                      }`}
                    >
                      {String.fromCharCode(65 + index)}) {option}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleNextQuestion}
                disabled={selectedAnswer === null}
                className="w-full bg-black hover:bg-gray-800 text-white py-3 rounded font-bold disabled:bg-gray-400"
              >
                {currentQuestion < questions.length - 1 ? 'Próxima Questão' : 'Finalizar Quiz'}
              </Button>

              <Button
                onClick={resetQuiz}
                className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 rounded font-bold"
              >
                Reiniciar Quiz
              </Button>
            </div>
          </div>

          {/* Navigation */}
          <div className="p-6 pt-0 space-y-2">
            <Button
              onClick={() => onNavigate('dashboard')}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 rounded font-bold"
            >
              ← Voltar ao Menu
            </Button>
            
            <Button
              onClick={onLogout}
              className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2 rounded font-bold"
            >
              Sair
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default QuestoesScreen;
