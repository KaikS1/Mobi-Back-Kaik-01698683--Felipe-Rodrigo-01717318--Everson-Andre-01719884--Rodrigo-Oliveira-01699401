
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ConcursosScreenProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const ConcursosScreen = ({ onNavigate, onLogout }: ConcursosScreenProps) => {
  const concursoCategories = [
    { id: 'inicio', label: 'Início', active: false },
    { id: 'inscricoes', label: 'Inscrições abertas', active: false },
    { id: 'previstos', label: 'Previstos', active: false },
    { id: 'autorizados', label: 'Autorizados', active: false },
    { id: 'abertos', label: 'Abertos', active: false },
  ];

  return (
    <div className="min-h-screen bg-gray-200 p-4">
      <Card className="w-full max-w-sm mx-auto bg-white shadow-xl rounded-3xl overflow-hidden">
        <CardContent className="p-0">
          {/* Header */}
          <div className="bg-gray-300 p-8 text-center">
            <img 
              src="/lovable-uploads/693b503d-750d-4af9-ada6-fe7582742071.png" 
              alt="Tactical Team" 
              className="w-32 h-24 mx-auto mb-4 object-cover rounded-lg"
            />
            <h1 className="text-xl font-black text-black tracking-wider">
              DE OLHO NA VAGA
            </h1>
          </div>

          {/* Concursos Header */}
          <div className="px-6 pt-6">
            <div className="bg-gray-600 text-white px-4 py-2 rounded font-bold text-center mb-4">
              Concursos
            </div>
          </div>

          {/* Categories */}
          <div className="p-6 pt-0 space-y-3">
            {concursoCategories.map((category) => (
              <button
                key={category.id}
                className="w-full bg-gray-200 hover:bg-gray-300 text-black px-4 py-3 rounded font-bold text-left transition-colors"
              >
                {category.label}
              </button>
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="p-6 pt-0 space-y-2">
            <Button
              onClick={() => onNavigate('dashboard')}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 rounded font-bold"
            >
              ← Voltar ao Menu
            </Button>
            
            <Button
              onClick={onLogout}
              className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2 rounded font-bold"
            >
              Sair
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ConcursosScreen;
