
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface DisciplinasScreenProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const DisciplinasScreen = ({ onNavigate, onLogout }: DisciplinasScreenProps) => {
  const disciplinas = [
    { id: 'portugues', name: 'Português', questionsCount: 250 },
    { id: 'matematica', name: 'Matemática', questionsCount: 180 },
    { id: 'direito', name: 'Direito Constitucional', questionsCount: 320 },
    { id: 'penal', name: 'Direito Penal', questionsCount: 200 },
    { id: 'administrativo', name: 'Direito Administrativo', questionsCount: 150 },
    { id: 'informatica', name: 'Informática', questionsCount: 100 },
    { id: 'conhecimentos', name: 'Conhecimentos Gerais', questionsCount: 300 },
    { id: 'raciocinio', name: 'Raciocínio Lógico', questionsCount: 120 },
  ];

  return (
    <div className="min-h-screen bg-gray-200 p-4">
      <Card className="w-full max-w-sm mx-auto bg-white shadow-xl rounded-3xl overflow-hidden">
        <CardContent className="p-0">
          {/* Header */}
          <div className="bg-gray-300 p-8 text-center">
            <img 
              src="/lovable-uploads/693b503d-750d-4af9-ada6-fe7582742071.png" 
              alt="Tactical Team" 
              className="w-32 h-24 mx-auto mb-4 object-cover rounded-lg"
            />
            <h1 className="text-xl font-black text-black tracking-wider">
              DE OLHO NA VAGA
            </h1>
          </div>

          {/* Disciplinas Header */}
          <div className="px-6 pt-6">
            <div className="bg-gray-600 text-white px-4 py-2 rounded font-bold text-center mb-4">
              Disciplinas
            </div>
          </div>

          {/* Disciplinas List */}
          <div className="p-6 pt-0 space-y-3 max-h-96 overflow-y-auto">
            {disciplinas.map((disciplina) => (
              <button
                key={disciplina.id}
                className="w-full bg-gray-200 hover:bg-gray-300 text-black px-4 py-3 rounded font-bold text-left transition-colors flex justify-between items-center"
              >
                <span>📚 {disciplina.name}</span>
                <span className="text-sm bg-gray-600 text-white px-2 py-1 rounded">
                  {disciplina.questionsCount}
                </span>
              </button>
            ))}
          </div>

          {/* Navigation Buttons */}
          <div className="p-6 pt-4 space-y-2">
            <Button
              onClick={() => onNavigate('dashboard')}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white py-2 rounded font-bold"
            >
              ← Voltar ao Menu
            </Button>
            
            <Button
              onClick={onLogout}
              className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2 rounded font-bold"
            >
              Sair
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DisciplinasScreen;
