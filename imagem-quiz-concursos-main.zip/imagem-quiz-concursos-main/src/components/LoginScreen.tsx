
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";

interface LoginScreenProps {
  onLogin: () => void;
}

const LoginScreen = ({ onLogin }: LoginScreenProps) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen bg-gray-200 flex items-center justify-center p-4">
      <Card className="w-full max-w-sm bg-white shadow-xl rounded-3xl overflow-hidden">
        <CardContent className="p-0">
          {/* Header with tactical image */}
          <div className="bg-gray-300 p-8 text-center">
            <img 
              src="/lovable-uploads/693b503d-750d-4af9-ada6-fe7582742071.png" 
              alt="Tactical Team" 
              className="w-32 h-24 mx-auto mb-4 object-cover rounded-lg"
            />
            <h1 className="text-xl font-black text-black tracking-wider">
              DE OLHO NA VAGA
            </h1>
          </div>

          {/* Login Form */}
          <div className="p-6 space-y-6">
            <h2 className="text-2xl font-bold text-black">Entrar</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="text-black">📧</span>
                  <Input
                    type="email"
                    placeholder="Digite seu email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="border-b border-gray-300 rounded-none border-x-0 border-t-0 px-0 focus:border-black"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="text-black">🔒</span>
                  <Input
                    type="password"
                    placeholder="Digite sua senha"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="border-b border-gray-300 rounded-none border-x-0 border-t-0 px-0 focus:border-black"
                    required
                  />
                </div>
                <div className="text-right">
                  <button type="button" className="text-sm text-gray-500 hover:text-black">
                    Esqueceu a senha?
                  </button>
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-black hover:bg-gray-800 text-white py-3 rounded-lg font-semibold"
              >
                Acessar
              </Button>
            </form>

            <div className="text-center space-y-4">
              <p className="text-gray-500">Ou</p>
              
              <Button 
                variant="outline" 
                className="w-full py-3 bg-gray-100 hover:bg-gray-200 text-black rounded-lg font-semibold"
              >
                🌐 Entrar com o Google
              </Button>
              
              <button className="text-black hover:underline">
                Cadastre-se
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoginScreen;
