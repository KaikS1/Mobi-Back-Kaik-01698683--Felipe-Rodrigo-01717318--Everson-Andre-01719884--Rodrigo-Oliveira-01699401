
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface DashboardProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const Dashboard = ({ onNavigate, onLogout }: DashboardProps) => {
  const menuItems = [
    { id: 'concursos', label: 'Concursos', icon: '📋' },
    { id: 'questoes', label: 'Questões', icon: '❓' },
    { id: 'disciplinas', label: 'Disciplinas', icon: '📚' },
  ];

  return (
    <div className="min-h-screen bg-gray-200 p-4">
      <Card className="w-full max-w-sm mx-auto bg-white shadow-xl rounded-3xl overflow-hidden">
        <CardContent className="p-0">
          {/* Header */}
          <div className="bg-gray-300 p-8 text-center">
            <img 
              src="/lovable-uploads/693b503d-750d-4af9-ada6-fe7582742071.png" 
              alt="Tactical Team" 
              className="w-32 h-24 mx-auto mb-4 object-cover rounded-lg"
            />
            <h1 className="text-xl font-black text-black tracking-wider">
              DE OLHO NA VAGA
            </h1>
          </div>

          {/* Menu Items */}
          <div className="p-6 space-y-4">
            <div className="bg-gray-600 text-white px-4 py-2 rounded font-bold">
              Início
            </div>
            
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className="w-full bg-gray-200 hover:bg-gray-300 text-black px-4 py-3 rounded font-bold text-left transition-colors"
              >
                <span className="mr-3">{item.icon}</span>
                {item.label}
              </button>
            ))}
          </div>

          {/* Logout Button */}
          <div className="p-6 pt-0">
            <Button
              onClick={onLogout}
              className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2 rounded font-bold"
            >
              Sair
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
