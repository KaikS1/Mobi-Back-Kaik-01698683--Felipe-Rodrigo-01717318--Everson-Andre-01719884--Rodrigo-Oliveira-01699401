
import { useState } from "react";
import LoginScreen from "../components/LoginScreen";
import Dashboard from "../components/Dashboard";
import ConcursosScreen from "../components/ConcursosScreen";
import QuestoesScreen from "../components/QuestoesScreen";
import DisciplinasScreen from "../components/DisciplinasScreen";

const Index = () => {
  const [currentScreen, setCurrentScreen] = useState('login');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => {
    setIsLoggedIn(true);
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentScreen('login');
  };

  const navigateTo = (screen: string) => {
    setCurrentScreen(screen);
  };

  const renderScreen = () => {
    if (!isLoggedIn) {
      return <LoginScreen onLogin={handleLogin} />;
    }

    switch (currentScreen) {
      case 'dashboard':
        return <Dashboard onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'concursos':
        return <ConcursosScreen onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'questoes':
        return <QuestoesScreen onNavigate={navigateTo} onLogout={handleLogout} />;
      case 'disciplinas':
        return <DisciplinasScreen onNavigate={navigateTo} onLogout={handleLogout} />;
      default:
        return <Dashboard onNavigate={navigateTo} onLogout={handleLogout} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {renderScreen()}
    </div>
  );
};

export default Index;
